# io.swagger.client - Kotlin client library for Factom Open API

## Requires

* Kotlin 1.1.2
* Gradle 3.3

## Build

First, create the gradle wrapper script:

```
gradle wrapper
```

Then, run:

```
./gradlew check assemble
```

This runs all tests and packages the library.

## Features/Implementation Notes

* Supports JSON inputs/outputs, File inputs, and Form inputs.
* Supports collection formats for query parameters: csv, tsv, ssv, pipes.
* Some Kotlin and Java types are fully qualified to avoid conflicts with types defined in Swagger definitions.
* Implementation of ApiClient is intended to reduce method counts, specifically to benefit Android targets.

<a name="documentation-for-api-endpoints"></a>
## Documentation for API Endpoints

All URIs are relative to *https://localhost:8081/v1*

Class | Method | HTTP request | Description
------------ | ------------- | ------------- | -------------
*DefaultApi* | [**chainsChainIdEntriesFirstGet**](docs/DefaultApi.md#chainschainidentriesfirstget) | **GET** /chains/{chainId}/entries/first | Get first entry of the chain
*DefaultApi* | [**chainsChainIdEntriesGet**](docs/DefaultApi.md#chainschainidentriesget) | **GET** /chains/{chainId}/entries | Get chain entries
*DefaultApi* | [**chainsChainIdEntriesLastGet**](docs/DefaultApi.md#chainschainidentrieslastget) | **GET** /chains/{chainId}/entries/last | Get last entry of the chain
*DefaultApi* | [**chainsChainIdEntriesSearchPost**](docs/DefaultApi.md#chainschainidentriessearchpost) | **POST** /chains/{chainId}/entries/search | Search entries of chain
*DefaultApi* | [**chainsChainIdGet**](docs/DefaultApi.md#chainschainidget) | **GET** /chains/{chainId} | Get chain
*DefaultApi* | [**chainsGet**](docs/DefaultApi.md#chainsget) | **GET** /chains | Get chains
*DefaultApi* | [**chainsPost**](docs/DefaultApi.md#chainspost) | **POST** /chains | Create a chain
*DefaultApi* | [**chainsSearchPost**](docs/DefaultApi.md#chainssearchpost) | **POST** /chains/search | Search chains
*DefaultApi* | [**entriesEntryHashGet**](docs/DefaultApi.md#entriesentryhashget) | **GET** /entries/{entryHash} | Get entry
*DefaultApi* | [**entriesPost**](docs/DefaultApi.md#entriespost) | **POST** /entries | Create an entry
*DefaultApi* | [**factomdMethodPost**](docs/DefaultApi.md#factomdmethodpost) | **POST** /factomd/{method} | Generic factomd
*DefaultApi* | [**rootGet**](docs/DefaultApi.md#rootget) | **GET** / | API info
*DefaultApi* | [**userGet**](docs/DefaultApi.md#userget) | **GET** /user | User info


<a name="documentation-for-models"></a>
## Documentation for Models

 - [io.swagger.client.models.ApiErrorResponse](docs/ApiErrorResponse.md)
 - [io.swagger.client.models.ApiSuccessResponse](docs/ApiSuccessResponse.md)
 - [io.swagger.client.models.ApiSuccessResponsePagination](docs/ApiSuccessResponsePagination.md)


<a name="documentation-for-authorization"></a>
## Documentation for Authorization

<a name="ApiKeyAuth"></a>
### ApiKeyAuth

- **Type**: API key
- **API key parameter name**: Authorization
- **Location**: HTTP header

