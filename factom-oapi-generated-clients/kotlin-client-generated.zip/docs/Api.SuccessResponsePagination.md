
# ApiSuccessResponsePagination

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **kotlin.Int** |  |  [optional]
**result** | [**kotlin.Any**](kotlin.Any.md) |  |  [optional]
**start** | **kotlin.Int** |  |  [optional]
**total** | **kotlin.Int** |  |  [optional]



