# DefaultApi

All URIs are relative to *https://localhost:8081/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**chainsChainIdEntriesFirstGet**](DefaultApi.md#chainsChainIdEntriesFirstGet) | **GET** /chains/{chainId}/entries/first | Get first entry of the chain
[**chainsChainIdEntriesGet**](DefaultApi.md#chainsChainIdEntriesGet) | **GET** /chains/{chainId}/entries | Get chain entries
[**chainsChainIdEntriesLastGet**](DefaultApi.md#chainsChainIdEntriesLastGet) | **GET** /chains/{chainId}/entries/last | Get last entry of the chain
[**chainsChainIdEntriesSearchPost**](DefaultApi.md#chainsChainIdEntriesSearchPost) | **POST** /chains/{chainId}/entries/search | Search entries of chain
[**chainsChainIdGet**](DefaultApi.md#chainsChainIdGet) | **GET** /chains/{chainId} | Get chain
[**chainsGet**](DefaultApi.md#chainsGet) | **GET** /chains | Get chains
[**chainsPost**](DefaultApi.md#chainsPost) | **POST** /chains | Create a chain
[**chainsSearchPost**](DefaultApi.md#chainsSearchPost) | **POST** /chains/search | Search chains
[**entriesEntryHashGet**](DefaultApi.md#entriesEntryHashGet) | **GET** /entries/{entryHash} | Get entry
[**entriesPost**](DefaultApi.md#entriesPost) | **POST** /entries | Create an entry
[**factomdMethodPost**](DefaultApi.md#factomdMethodPost) | **POST** /factomd/{method} | Generic factomd
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | API info
[**userGet**](DefaultApi.md#userGet) | **GET** /user | User info


<a name="chainsChainIdEntriesFirstGet"></a>
# **chainsChainIdEntriesFirstGet**
> ApiSuccessResponse chainsChainIdEntriesFirstGet(chainId)

Get first entry of the chain

Returns first entry of Factom chain

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val chainId : kotlin.String = chainId_example // kotlin.String | Chain ID of the Factom chain.
try {
    val result : ApiSuccessResponse = apiInstance.chainsChainIdEntriesFirstGet(chainId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsChainIdEntriesFirstGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsChainIdEntriesFirstGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **kotlin.String**| Chain ID of the Factom chain. |

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="chainsChainIdEntriesGet"></a>
# **chainsChainIdEntriesGet**
> ApiSuccessResponsePagination chainsChainIdEntriesGet(chainId, start, limit, status, sort)

Get chain entries

Returns entries of Factom chain

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val chainId : kotlin.String = chainId_example // kotlin.String | Chain ID of the Factom chain.
val start : kotlin.Int = 56 // kotlin.Int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
val limit : kotlin.Int = 56 // kotlin.Int | The number of items you would like back in each page.<br />*Default: 30*
val status : kotlin.String = status_example // kotlin.String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
val sort : kotlin.String = sort_example // kotlin.String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*
try {
    val result : ApiSuccessResponsePagination = apiInstance.chainsChainIdEntriesGet(chainId, start, limit, status, sort)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsChainIdEntriesGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsChainIdEntriesGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **kotlin.String**| Chain ID of the Factom chain. |
 **start** | **kotlin.Int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional]
 **limit** | **kotlin.Int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional]
 **status** | **kotlin.String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional]
 **sort** | **kotlin.String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional]

### Return type

[**ApiSuccessResponsePagination**](ApiSuccessResponsePagination.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="chainsChainIdEntriesLastGet"></a>
# **chainsChainIdEntriesLastGet**
> ApiSuccessResponse chainsChainIdEntriesLastGet(chainId)

Get last entry of the chain

Returns last entry of Factom chain

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val chainId : kotlin.String = chainId_example // kotlin.String | Chain ID of the Factom chain.
try {
    val result : ApiSuccessResponse = apiInstance.chainsChainIdEntriesLastGet(chainId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsChainIdEntriesLastGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsChainIdEntriesLastGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **kotlin.String**| Chain ID of the Factom chain. |

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="chainsChainIdEntriesSearchPost"></a>
# **chainsChainIdEntriesSearchPost**
> ApiSuccessResponsePagination chainsChainIdEntriesSearchPost(chainId, extIds, start, limit, status, sort)

Search entries of chain

Search entries into Factom chain by external id(s)

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val chainId : kotlin.String = chainId_example // kotlin.String | Chain ID of the Factom chain.
val extIds : kotlin.Array<kotlin.String> =  // kotlin.Array<kotlin.String> | One or many external IDs, that used for search.<br />**Should be provided as array of base64 strings.**
val start : kotlin.Int = 56 // kotlin.Int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
val limit : kotlin.Int = 56 // kotlin.Int | The number of items you would like back in each page.<br />*Default: 30*
val status : kotlin.String = status_example // kotlin.String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
val sort : kotlin.String = sort_example // kotlin.String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*
try {
    val result : ApiSuccessResponsePagination = apiInstance.chainsChainIdEntriesSearchPost(chainId, extIds, start, limit, status, sort)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsChainIdEntriesSearchPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsChainIdEntriesSearchPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **kotlin.String**| Chain ID of the Factom chain. |
 **extIds** | [**kotlin.Array&lt;kotlin.String&gt;**](kotlin.String.md)| One or many external IDs, that used for search.&lt;br /&gt;**Should be provided as array of base64 strings.** |
 **start** | **kotlin.Int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional]
 **limit** | **kotlin.Int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional]
 **status** | **kotlin.String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional]
 **sort** | **kotlin.String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional]

### Return type

[**ApiSuccessResponsePagination**](ApiSuccessResponsePagination.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="chainsChainIdGet"></a>
# **chainsChainIdGet**
> ApiSuccessResponse chainsChainIdGet(chainId)

Get chain

Returns Factom chain by Chain ID

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val chainId : kotlin.String = chainId_example // kotlin.String | Chain ID of the Factom chain.
try {
    val result : ApiSuccessResponse = apiInstance.chainsChainIdGet(chainId)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsChainIdGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsChainIdGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **kotlin.String**| Chain ID of the Factom chain. |

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="chainsGet"></a>
# **chainsGet**
> ApiSuccessResponsePagination chainsGet(start, limit, status, sort)

Get chains

Returns all user&#39;s chains

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val start : kotlin.Int = 56 // kotlin.Int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
val limit : kotlin.Int = 56 // kotlin.Int | The number of items you would like back in each page.<br />*Default: 30*
val status : kotlin.String = status_example // kotlin.String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
val sort : kotlin.String = sort_example // kotlin.String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*
try {
    val result : ApiSuccessResponsePagination = apiInstance.chainsGet(start, limit, status, sort)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start** | **kotlin.Int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional]
 **limit** | **kotlin.Int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional]
 **status** | **kotlin.String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional]
 **sort** | **kotlin.String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional]

### Return type

[**ApiSuccessResponsePagination**](ApiSuccessResponsePagination.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="chainsPost"></a>
# **chainsPost**
> ApiSuccessResponse chainsPost(extIds, content)

Create a chain

Creates chain on the Factom blockchain

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val extIds : kotlin.Array<kotlin.String> =  // kotlin.Array<kotlin.String> | One or many external ids identifying new chain.<br />**Should be provided as array of base64 strings.**
val content : kotlin.String = content_example // kotlin.String | The content of the first entry of the chain.<br />**Should be provided as base64 string.**
try {
    val result : ApiSuccessResponse = apiInstance.chainsPost(extIds, content)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extIds** | [**kotlin.Array&lt;kotlin.String&gt;**](kotlin.String.md)| One or many external ids identifying new chain.&lt;br /&gt;**Should be provided as array of base64 strings.** |
 **content** | **kotlin.String**| The content of the first entry of the chain.&lt;br /&gt;**Should be provided as base64 string.** | [optional]

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="chainsSearchPost"></a>
# **chainsSearchPost**
> ApiSuccessResponse chainsSearchPost(extIds, start, limit, status, sort)

Search chains

Search user&#39;s chains by external id(s)

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val extIds : kotlin.Array<kotlin.String> =  // kotlin.Array<kotlin.String> | One or many external IDs, that used for search.<br />**Should be provided as array of base64 strings.**
val start : kotlin.Int = 56 // kotlin.Int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
val limit : kotlin.Int = 56 // kotlin.Int | The number of items you would like back in each page.<br />*Default: 30*
val status : kotlin.String = status_example // kotlin.String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
val sort : kotlin.String = sort_example // kotlin.String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*
try {
    val result : ApiSuccessResponse = apiInstance.chainsSearchPost(extIds, start, limit, status, sort)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#chainsSearchPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#chainsSearchPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extIds** | [**kotlin.Array&lt;kotlin.String&gt;**](kotlin.String.md)| One or many external IDs, that used for search.&lt;br /&gt;**Should be provided as array of base64 strings.** |
 **start** | **kotlin.Int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional]
 **limit** | **kotlin.Int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional]
 **status** | **kotlin.String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional]
 **sort** | **kotlin.String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional]

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="entriesEntryHashGet"></a>
# **entriesEntryHashGet**
> ApiSuccessResponse entriesEntryHashGet(entryHash)

Get entry

Returns Factom entry by EntryHash

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val entryHash : kotlin.String = entryHash_example // kotlin.String | EntryHash of the Factom entry.
try {
    val result : ApiSuccessResponse = apiInstance.entriesEntryHashGet(entryHash)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#entriesEntryHashGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#entriesEntryHashGet")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entryHash** | **kotlin.String**| EntryHash of the Factom entry. |

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="entriesPost"></a>
# **entriesPost**
> ApiSuccessResponse entriesPost(chainId, extIds, content)

Create an entry

Creates entry on the Factom blockchain

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val chainId : kotlin.String = chainId_example // kotlin.String | Chain ID of the Factom chain, where to add new entry.
val extIds : kotlin.Array<kotlin.String> =  // kotlin.Array<kotlin.String> | One or many external ids identifying new chain.<br />**Should be provided as array of base64 strings.**
val content : kotlin.String = content_example // kotlin.String | The content of the new entry of the chain.<br />**Should be provided as base64 string.**
try {
    val result : ApiSuccessResponse = apiInstance.entriesPost(chainId, extIds, content)
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#entriesPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#entriesPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **kotlin.String**| Chain ID of the Factom chain, where to add new entry. |
 **extIds** | [**kotlin.Array&lt;kotlin.String&gt;**](kotlin.String.md)| One or many external ids identifying new chain.&lt;br /&gt;**Should be provided as array of base64 strings.** | [optional]
 **content** | **kotlin.String**| The content of the new entry of the chain.&lt;br /&gt;**Should be provided as base64 string.** | [optional]

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="factomdMethodPost"></a>
# **factomdMethodPost**
> factomdMethodPost(method, params)

Generic factomd

Sends direct request to factomd API

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
val method : kotlin.String = method_example // kotlin.String | factomd API method
val params : kotlin.String = params_example // kotlin.String | factomd request's params.<br />**Should be provided as JSON string,** e.g. *{'chainid':'XXXX'}*
try {
    apiInstance.factomdMethodPost(method, params)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#factomdMethodPost")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#factomdMethodPost")
    e.printStackTrace()
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **method** | **kotlin.String**| factomd API method |
 **params** | **kotlin.String**| factomd request&#39;s params.&lt;br /&gt;**Should be provided as JSON string,** e.g. *{&#39;chainid&#39;:&#39;XXXX&#39;}* | [optional]

### Return type

null (empty response body)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="rootGet"></a>
# **rootGet**
> ApiSuccessResponse rootGet()

API info

Get API version

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
try {
    val result : ApiSuccessResponse = apiInstance.rootGet()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#rootGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#rootGet")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

<a name="userGet"></a>
# **userGet**
> ApiSuccessResponse userGet()

User info

Get API user info

### Example
```kotlin
// Import classes:
//import io.swagger.client.infrastructure.*
//import io.swagger.client.models.*

val apiInstance = DefaultApi()
try {
    val result : ApiSuccessResponse = apiInstance.userGet()
    println(result)
} catch (e: ClientException) {
    println("4xx response calling DefaultApi#userGet")
    e.printStackTrace()
} catch (e: ServerException) {
    println("5xx response calling DefaultApi#userGet")
    e.printStackTrace()
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

