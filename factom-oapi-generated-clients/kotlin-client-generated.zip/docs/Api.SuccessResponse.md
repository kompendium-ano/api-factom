
# ApiSuccessResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**result** | [**kotlin.Any**](kotlin.Any.md) |  |  [optional]



