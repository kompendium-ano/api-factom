
# ApiErrorResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**code** | **kotlin.Int** |  |  [optional]
**error** | **kotlin.String** |  |  [optional]
**result** | **kotlin.Boolean** |  |  [optional]



