# swagger.api.DefaultApi

## Load the API package
```dart
import 'package:swagger/api.dart';
```

All URIs are relative to *https://localhost:8081/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**chainsChainIdEntriesFirstGet**](DefaultApi.md#chainsChainIdEntriesFirstGet) | **GET** /chains/{chainId}/entries/first | Get first entry of the chain
[**chainsChainIdEntriesGet**](DefaultApi.md#chainsChainIdEntriesGet) | **GET** /chains/{chainId}/entries | Get chain entries
[**chainsChainIdEntriesLastGet**](DefaultApi.md#chainsChainIdEntriesLastGet) | **GET** /chains/{chainId}/entries/last | Get last entry of the chain
[**chainsChainIdEntriesSearchPost**](DefaultApi.md#chainsChainIdEntriesSearchPost) | **POST** /chains/{chainId}/entries/search | Search entries of chain
[**chainsChainIdGet**](DefaultApi.md#chainsChainIdGet) | **GET** /chains/{chainId} | Get chain
[**chainsGet**](DefaultApi.md#chainsGet) | **GET** /chains | Get chains
[**chainsPost**](DefaultApi.md#chainsPost) | **POST** /chains | Create a chain
[**chainsSearchPost**](DefaultApi.md#chainsSearchPost) | **POST** /chains/search | Search chains
[**entriesEntryHashGet**](DefaultApi.md#entriesEntryHashGet) | **GET** /entries/{entryHash} | Get entry
[**entriesPost**](DefaultApi.md#entriesPost) | **POST** /entries | Create an entry
[**factomdMethodPost**](DefaultApi.md#factomdMethodPost) | **POST** /factomd/{method} | Generic factomd
[**rootGet**](DefaultApi.md#rootGet) | **GET** / | API info
[**userGet**](DefaultApi.md#userGet) | **GET** /user | User info


# **chainsChainIdEntriesFirstGet**
> ApiSuccessResponse chainsChainIdEntriesFirstGet(chainId)

Get first entry of the chain

Returns first entry of Factom chain

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var chainId = chainId_example; // String | Chain ID of the Factom chain.

try { 
    var result = api_instance.chainsChainIdEntriesFirstGet(chainId);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsChainIdEntriesFirstGet: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **String**| Chain ID of the Factom chain. | 

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chainsChainIdEntriesGet**
> ApiSuccessResponsePagination chainsChainIdEntriesGet(chainId, start, limit, status, sort)

Get chain entries

Returns entries of Factom chain

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var chainId = chainId_example; // String | Chain ID of the Factom chain.
var start = 56; // int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
var limit = 56; // int | The number of items you would like back in each page.<br />*Default: 30*
var status = status_example; // String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
var sort = sort_example; // String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*

try { 
    var result = api_instance.chainsChainIdEntriesGet(chainId, start, limit, status, sort);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsChainIdEntriesGet: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **String**| Chain ID of the Factom chain. | 
 **start** | **int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional] 
 **limit** | **int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional] 
 **status** | **String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional] 
 **sort** | **String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional] 

### Return type

[**ApiSuccessResponsePagination**](ApiSuccessResponsePagination.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chainsChainIdEntriesLastGet**
> ApiSuccessResponse chainsChainIdEntriesLastGet(chainId)

Get last entry of the chain

Returns last entry of Factom chain

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var chainId = chainId_example; // String | Chain ID of the Factom chain.

try { 
    var result = api_instance.chainsChainIdEntriesLastGet(chainId);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsChainIdEntriesLastGet: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **String**| Chain ID of the Factom chain. | 

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chainsChainIdEntriesSearchPost**
> ApiSuccessResponsePagination chainsChainIdEntriesSearchPost(chainId, extIds, start, limit, status, sort)

Search entries of chain

Search entries into Factom chain by external id(s)

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var chainId = chainId_example; // String | Chain ID of the Factom chain.
var extIds = []; // List<String> | One or many external IDs, that used for search.<br />**Should be provided as array of base64 strings.**
var start = 56; // int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
var limit = 56; // int | The number of items you would like back in each page.<br />*Default: 30*
var status = status_example; // String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
var sort = sort_example; // String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*

try { 
    var result = api_instance.chainsChainIdEntriesSearchPost(chainId, extIds, start, limit, status, sort);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsChainIdEntriesSearchPost: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **String**| Chain ID of the Factom chain. | 
 **extIds** | [**List&lt;String&gt;**](String.md)| One or many external IDs, that used for search.&lt;br /&gt;**Should be provided as array of base64 strings.** | 
 **start** | **int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional] 
 **limit** | **int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional] 
 **status** | **String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional] 
 **sort** | **String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional] 

### Return type

[**ApiSuccessResponsePagination**](ApiSuccessResponsePagination.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chainsChainIdGet**
> ApiSuccessResponse chainsChainIdGet(chainId)

Get chain

Returns Factom chain by Chain ID

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var chainId = chainId_example; // String | Chain ID of the Factom chain.

try { 
    var result = api_instance.chainsChainIdGet(chainId);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsChainIdGet: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **String**| Chain ID of the Factom chain. | 

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chainsGet**
> ApiSuccessResponsePagination chainsGet(start, limit, status, sort)

Get chains

Returns all user's chains

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var start = 56; // int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
var limit = 56; // int | The number of items you would like back in each page.<br />*Default: 30*
var status = status_example; // String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
var sort = sort_example; // String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*

try { 
    var result = api_instance.chainsGet(start, limit, status, sort);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsGet: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **start** | **int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional] 
 **limit** | **int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional] 
 **status** | **String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional] 
 **sort** | **String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional] 

### Return type

[**ApiSuccessResponsePagination**](ApiSuccessResponsePagination.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chainsPost**
> ApiSuccessResponse chainsPost(extIds, content)

Create a chain

Creates chain on the Factom blockchain

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var extIds = []; // List<String> | One or many external ids identifying new chain.<br />**Should be provided as array of base64 strings.**
var content = content_example; // String | The content of the first entry of the chain.<br />**Should be provided as base64 string.**

try { 
    var result = api_instance.chainsPost(extIds, content);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsPost: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extIds** | [**List&lt;String&gt;**](String.md)| One or many external ids identifying new chain.&lt;br /&gt;**Should be provided as array of base64 strings.** | 
 **content** | **String**| The content of the first entry of the chain.&lt;br /&gt;**Should be provided as base64 string.** | [optional] 

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **chainsSearchPost**
> ApiSuccessResponse chainsSearchPost(extIds, start, limit, status, sort)

Search chains

Search user's chains by external id(s)

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var extIds = []; // List<String> | One or many external IDs, that used for search.<br />**Should be provided as array of base64 strings.**
var start = 56; // int | Select item you would like to start.<br />E.g. if you've already seen 30 items and want to see next 30, then you will provide **start=30**.<br />*Default: 0*
var limit = 56; // int | The number of items you would like back in each page.<br />*Default: 30*
var status = status_example; // String | Filter results by chain's status.<br />One of: **queue**, **processing**, **completed**<br />*By default filtering disabled.*
var sort = sort_example; // String | Sorting order.<br />One of: **asc** or **desc**<br />*Default: desc*

try { 
    var result = api_instance.chainsSearchPost(extIds, start, limit, status, sort);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->chainsSearchPost: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **extIds** | [**List&lt;String&gt;**](String.md)| One or many external IDs, that used for search.&lt;br /&gt;**Should be provided as array of base64 strings.** | 
 **start** | **int**| Select item you would like to start.&lt;br /&gt;E.g. if you&#39;ve already seen 30 items and want to see next 30, then you will provide **start&#x3D;30**.&lt;br /&gt;*Default: 0* | [optional] 
 **limit** | **int**| The number of items you would like back in each page.&lt;br /&gt;*Default: 30* | [optional] 
 **status** | **String**| Filter results by chain&#39;s status.&lt;br /&gt;One of: **queue**, **processing**, **completed**&lt;br /&gt;*By default filtering disabled.* | [optional] 
 **sort** | **String**| Sorting order.&lt;br /&gt;One of: **asc** or **desc**&lt;br /&gt;*Default: desc* | [optional] 

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **entriesEntryHashGet**
> ApiSuccessResponse entriesEntryHashGet(entryHash)

Get entry

Returns Factom entry by EntryHash

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var entryHash = entryHash_example; // String | EntryHash of the Factom entry.

try { 
    var result = api_instance.entriesEntryHashGet(entryHash);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->entriesEntryHashGet: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **entryHash** | **String**| EntryHash of the Factom entry. | 

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **entriesPost**
> ApiSuccessResponse entriesPost(chainId, extIds, content)

Create an entry

Creates entry on the Factom blockchain

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var chainId = chainId_example; // String | Chain ID of the Factom chain, where to add new entry.
var extIds = []; // List<String> | One or many external ids identifying new chain.<br />**Should be provided as array of base64 strings.**
var content = content_example; // String | The content of the new entry of the chain.<br />**Should be provided as base64 string.**

try { 
    var result = api_instance.entriesPost(chainId, extIds, content);
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->entriesPost: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chainId** | **String**| Chain ID of the Factom chain, where to add new entry. | 
 **extIds** | [**List&lt;String&gt;**](String.md)| One or many external ids identifying new chain.&lt;br /&gt;**Should be provided as array of base64 strings.** | [optional] 
 **content** | **String**| The content of the new entry of the chain.&lt;br /&gt;**Should be provided as base64 string.** | [optional] 

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **factomdMethodPost**
> factomdMethodPost(method, params)

Generic factomd

Sends direct request to factomd API

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();
var method = method_example; // String | factomd API method
var params = params_example; // String | factomd request's params.<br />**Should be provided as JSON string,** e.g. *{'chainid':'XXXX'}*

try { 
    api_instance.factomdMethodPost(method, params);
} catch (e) {
    print("Exception when calling DefaultApi->factomdMethodPost: $e\n");
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **method** | **String**| factomd API method | 
 **params** | **String**| factomd request&#39;s params.&lt;br /&gt;**Should be provided as JSON string,** e.g. *{&#39;chainid&#39;:&#39;XXXX&#39;}* | [optional] 

### Return type

void (empty response body)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **rootGet**
> ApiSuccessResponse rootGet()

API info

Get API version

### Example 
```dart
import 'package:swagger/api.dart';

var api_instance = new DefaultApi();

try { 
    var result = api_instance.rootGet();
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->rootGet: $e\n");
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **userGet**
> ApiSuccessResponse userGet()

User info

Get API user info

### Example 
```dart
import 'package:swagger/api.dart';
// TODO Configure API key authorization: ApiKeyAuth
//swagger.api.Configuration.apiKey{'Authorization'} = 'YOUR_API_KEY';
// uncomment below to setup prefix (e.g. Bearer) for API key, if needed
//swagger.api.Configuration.apiKeyPrefix{'Authorization'} = "Bearer";

var api_instance = new DefaultApi();

try { 
    var result = api_instance.userGet();
    print(result);
} catch (e) {
    print("Exception when calling DefaultApi->userGet: $e\n");
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**ApiSuccessResponse**](ApiSuccessResponse.md)

### Authorization

[ApiKeyAuth](../README.md#ApiKeyAuth)

### HTTP request headers

 - **Content-Type**: application/x-www-form-urlencoded, application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

