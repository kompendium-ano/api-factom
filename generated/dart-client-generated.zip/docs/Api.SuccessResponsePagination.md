# swagger.model.ApiSuccessResponsePagination

## Load the model package
```dart
import 'package:swagger/api.dart';
```

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**limit** | **int** |  | [optional] [default to null]
**result** | [**Object**](Object.md) |  | [optional] [default to null]
**start** | **int** |  | [optional] [default to null]
**total** | **int** |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


