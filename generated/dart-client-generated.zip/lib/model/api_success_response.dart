part of swagger.api;

class ApiSuccessResponse {
  
  Object result = null;
  
  ApiSuccessResponse();

  @override
  String toString() {
    return 'ApiSuccessResponse[result=$result, ]';
  }

  ApiSuccessResponse.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    result =
      
      
      new Object.fromJson(json['result'])
;
  }

  Map<String, dynamic> toJson() {
    return {
      'result': result
     };
  }

  static List<ApiSuccessResponse> listFromJson(List<dynamic> json) {
    return json == null ? new List<ApiSuccessResponse>() : json.map((value) => new ApiSuccessResponse.fromJson(value)).toList();
  }

  static Map<String, ApiSuccessResponse> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ApiSuccessResponse>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ApiSuccessResponse.fromJson(value));
    }
    return map;
  }
}

