part of swagger.api;

class ApiErrorResponse {
  
  int code = null;
  

  String error = null;
  

  bool result = null;
  
  ApiErrorResponse();

  @override
  String toString() {
    return 'ApiErrorResponse[code=$code, error=$error, result=$result, ]';
  }

  ApiErrorResponse.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    code =
        json['code']
    ;
    error =
        json['error']
    ;
    result =
        json['result']
    ;
  }

  Map<String, dynamic> toJson() {
    return {
      'code': code,
      'error': error,
      'result': result
     };
  }

  static List<ApiErrorResponse> listFromJson(List<dynamic> json) {
    return json == null ? new List<ApiErrorResponse>() : json.map((value) => new ApiErrorResponse.fromJson(value)).toList();
  }

  static Map<String, ApiErrorResponse> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ApiErrorResponse>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ApiErrorResponse.fromJson(value));
    }
    return map;
  }
}

