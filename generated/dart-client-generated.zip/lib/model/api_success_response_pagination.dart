part of swagger.api;

class ApiSuccessResponsePagination {
  
  int limit = null;
  

  Object result = null;
  

  int start = null;
  

  int total = null;
  
  ApiSuccessResponsePagination();

  @override
  String toString() {
    return 'ApiSuccessResponsePagination[limit=$limit, result=$result, start=$start, total=$total, ]';
  }

  ApiSuccessResponsePagination.fromJson(Map<String, dynamic> json) {
    if (json == null) return;
    limit =
        json['limit']
    ;
    result =
      
      
      new Object.fromJson(json['result'])
;
    start =
        json['start']
    ;
    total =
        json['total']
    ;
  }

  Map<String, dynamic> toJson() {
    return {
      'limit': limit,
      'result': result,
      'start': start,
      'total': total
     };
  }

  static List<ApiSuccessResponsePagination> listFromJson(List<dynamic> json) {
    return json == null ? new List<ApiSuccessResponsePagination>() : json.map((value) => new ApiSuccessResponsePagination.fromJson(value)).toList();
  }

  static Map<String, ApiSuccessResponsePagination> mapFromJson(Map<String, Map<String, dynamic>> json) {
    var map = new Map<String, ApiSuccessResponsePagination>();
    if (json != null && json.length > 0) {
      json.forEach((String key, Map<String, dynamic> value) => map[key] = new ApiSuccessResponsePagination.fromJson(value));
    }
    return map;
  }
}

