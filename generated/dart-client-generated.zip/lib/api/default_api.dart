part of swagger.api;



class DefaultApi {
  final ApiClient apiClient;

  DefaultApi([ApiClient apiClient]) : apiClient = apiClient ?? defaultApiClient;

  /// Get first entry of the chain
  ///
  /// Returns first entry of Factom chain
  Future<ApiSuccessResponse> chainsChainIdEntriesFirstGet(String chainId) async {
    Object postBody = null;

    // verify required params are set
    if(chainId == null) {
     throw new ApiException(400, "Missing required param: chainId");
    }

    // create path and map variables
    String path = "/chains/{chainId}/entries/first".replaceAll("{format}","json").replaceAll("{" + "chainId" + "}", chainId.toString());

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// Get chain entries
  ///
  /// Returns entries of Factom chain
  Future<ApiSuccessResponsePagination> chainsChainIdEntriesGet(String chainId, { int start, int limit, String status, String sort }) async {
    Object postBody = null;

    // verify required params are set
    if(chainId == null) {
     throw new ApiException(400, "Missing required param: chainId");
    }

    // create path and map variables
    String path = "/chains/{chainId}/entries".replaceAll("{format}","json").replaceAll("{" + "chainId" + "}", chainId.toString());

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    if(start != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "start", start));
    }
    if(limit != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "limit", limit));
    }
    if(status != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "status", status));
    }
    if(sort != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "sort", sort));
    }
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponsePagination') as ApiSuccessResponsePagination ;
    } else {
      return null;
    }
  }
  /// Get last entry of the chain
  ///
  /// Returns last entry of Factom chain
  Future<ApiSuccessResponse> chainsChainIdEntriesLastGet(String chainId) async {
    Object postBody = null;

    // verify required params are set
    if(chainId == null) {
     throw new ApiException(400, "Missing required param: chainId");
    }

    // create path and map variables
    String path = "/chains/{chainId}/entries/last".replaceAll("{format}","json").replaceAll("{" + "chainId" + "}", chainId.toString());

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// Search entries of chain
  ///
  /// Search entries into Factom chain by external id(s)
  Future<ApiSuccessResponsePagination> chainsChainIdEntriesSearchPost(String chainId, List<String> extIds, { int start, int limit, String status, String sort }) async {
    Object postBody = null;

    // verify required params are set
    if(chainId == null) {
     throw new ApiException(400, "Missing required param: chainId");
    }
    if(extIds == null) {
     throw new ApiException(400, "Missing required param: extIds");
    }

    // create path and map variables
    String path = "/chains/{chainId}/entries/search".replaceAll("{format}","json").replaceAll("{" + "chainId" + "}", chainId.toString());

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    if(start != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "start", start));
    }
    if(limit != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "limit", limit));
    }
    if(status != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "status", status));
    }
    if(sort != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "sort", sort));
    }
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if (extIds != null) {
        hasFields = true;
        mp.fields['extIds'] = parameterToString(extIds);
      }
      
      if(hasFields)
        postBody = mp;
    }
    else {
      if (extIds != null)
        formParams['extIds'] = parameterToString(extIds);
    }

    var response = await apiClient.invokeAPI(path,
                                             'POST',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponsePagination') as ApiSuccessResponsePagination ;
    } else {
      return null;
    }
  }
  /// Get chain
  ///
  /// Returns Factom chain by Chain ID
  Future<ApiSuccessResponse> chainsChainIdGet(String chainId) async {
    Object postBody = null;

    // verify required params are set
    if(chainId == null) {
     throw new ApiException(400, "Missing required param: chainId");
    }

    // create path and map variables
    String path = "/chains/{chainId}".replaceAll("{format}","json").replaceAll("{" + "chainId" + "}", chainId.toString());

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// Get chains
  ///
  /// Returns all user&#39;s chains
  Future<ApiSuccessResponsePagination> chainsGet({ int start, int limit, String status, String sort }) async {
    Object postBody = null;

    // verify required params are set

    // create path and map variables
    String path = "/chains".replaceAll("{format}","json");

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    if(start != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "start", start));
    }
    if(limit != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "limit", limit));
    }
    if(status != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "status", status));
    }
    if(sort != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "sort", sort));
    }
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponsePagination') as ApiSuccessResponsePagination ;
    } else {
      return null;
    }
  }
  /// Create a chain
  ///
  /// Creates chain on the Factom blockchain
  Future<ApiSuccessResponse> chainsPost(List<String> extIds, { String content }) async {
    Object postBody = null;

    // verify required params are set
    if(extIds == null) {
     throw new ApiException(400, "Missing required param: extIds");
    }

    // create path and map variables
    String path = "/chains".replaceAll("{format}","json");

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if (extIds != null) {
        hasFields = true;
        mp.fields['extIds'] = parameterToString(extIds);
      }
      
      if (content != null) {
        hasFields = true;
        mp.fields['content'] = parameterToString(content);
      }
      
      if(hasFields)
        postBody = mp;
    }
    else {
      if (extIds != null)
        formParams['extIds'] = parameterToString(extIds);
if (content != null)
        formParams['content'] = parameterToString(content);
    }

    var response = await apiClient.invokeAPI(path,
                                             'POST',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// Search chains
  ///
  /// Search user&#39;s chains by external id(s)
  Future<ApiSuccessResponse> chainsSearchPost(List<String> extIds, { int start, int limit, String status, String sort }) async {
    Object postBody = null;

    // verify required params are set
    if(extIds == null) {
     throw new ApiException(400, "Missing required param: extIds");
    }

    // create path and map variables
    String path = "/chains/search".replaceAll("{format}","json");

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    if(start != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "start", start));
    }
    if(limit != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "limit", limit));
    }
    if(status != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "status", status));
    }
    if(sort != null) {
      queryParams.addAll(_convertParametersForCollectionFormat("", "sort", sort));
    }
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if (extIds != null) {
        hasFields = true;
        mp.fields['extIds'] = parameterToString(extIds);
      }
      
      if(hasFields)
        postBody = mp;
    }
    else {
      if (extIds != null)
        formParams['extIds'] = parameterToString(extIds);
    }

    var response = await apiClient.invokeAPI(path,
                                             'POST',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// Get entry
  ///
  /// Returns Factom entry by EntryHash
  Future<ApiSuccessResponse> entriesEntryHashGet(String entryHash) async {
    Object postBody = null;

    // verify required params are set
    if(entryHash == null) {
     throw new ApiException(400, "Missing required param: entryHash");
    }

    // create path and map variables
    String path = "/entries/{entryHash}".replaceAll("{format}","json").replaceAll("{" + "entryHash" + "}", entryHash.toString());

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// Create an entry
  ///
  /// Creates entry on the Factom blockchain
  Future<ApiSuccessResponse> entriesPost(String chainId, { List<String> extIds, String content }) async {
    Object postBody = null;

    // verify required params are set
    if(chainId == null) {
     throw new ApiException(400, "Missing required param: chainId");
    }

    // create path and map variables
    String path = "/entries".replaceAll("{format}","json");

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if (chainId != null) {
        hasFields = true;
        mp.fields['chainId'] = parameterToString(chainId);
      }
      
      if (extIds != null) {
        hasFields = true;
        mp.fields['extIds'] = parameterToString(extIds);
      }
      
      if (content != null) {
        hasFields = true;
        mp.fields['content'] = parameterToString(content);
      }
      
      if(hasFields)
        postBody = mp;
    }
    else {
      if (chainId != null)
        formParams['chainId'] = parameterToString(chainId);
if (extIds != null)
        formParams['extIds'] = parameterToString(extIds);
if (content != null)
        formParams['content'] = parameterToString(content);
    }

    var response = await apiClient.invokeAPI(path,
                                             'POST',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// Generic factomd
  ///
  /// Sends direct request to factomd API
  Future factomdMethodPost(String method, { String params }) async {
    Object postBody = null;

    // verify required params are set
    if(method == null) {
     throw new ApiException(400, "Missing required param: method");
    }

    // create path and map variables
    String path = "/factomd/{method}".replaceAll("{format}","json").replaceAll("{" + "method" + "}", method.toString());

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if (params != null) {
        hasFields = true;
        mp.fields['params'] = parameterToString(params);
      }
      
      if(hasFields)
        postBody = mp;
    }
    else {
      if (params != null)
        formParams['params'] = parameterToString(params);
    }

    var response = await apiClient.invokeAPI(path,
                                             'POST',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          ;
    } else {
      return ;
    }
  }
  /// API info
  ///
  /// Get API version
  Future<ApiSuccessResponse> rootGet() async {
    Object postBody = null;

    // verify required params are set

    // create path and map variables
    String path = "/".replaceAll("{format}","json");

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = [];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
  /// User info
  ///
  /// Get API user info
  Future<ApiSuccessResponse> userGet() async {
    Object postBody = null;

    // verify required params are set

    // create path and map variables
    String path = "/user".replaceAll("{format}","json");

    // query params
    List<QueryParam> queryParams = [];
    Map<String, String> headerParams = {};
    Map<String, String> formParams = {};
    
    List<String> contentTypes = ["application/x-www-form-urlencoded","application/json"];

    String contentType = contentTypes.length > 0 ? contentTypes[0] : "application/json";
    List<String> authNames = ["ApiKeyAuth"];

    if(contentType.startsWith("multipart/form-data")) {
      bool hasFields = false;
      MultipartRequest mp = new MultipartRequest(null, null);
      
      if(hasFields)
        postBody = mp;
    }
    else {
          }

    var response = await apiClient.invokeAPI(path,
                                             'GET',
                                             queryParams,
                                             postBody,
                                             headerParams,
                                             formParams,
                                             contentType,
                                             authNames);

    if(response.statusCode >= 400) {
      throw new ApiException(response.statusCode, response.body);
    } else if(response.body != null) {
      return 
          apiClient.deserialize(response.body, 'ApiSuccessResponse') as ApiSuccessResponse ;
    } else {
      return null;
    }
  }
}
